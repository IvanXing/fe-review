function unTriggeredFunc() {
    const a = 123
    console.log(123)
}
