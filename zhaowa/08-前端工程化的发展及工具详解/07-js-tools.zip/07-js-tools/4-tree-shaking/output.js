function add(a, b) {
    return a + b;
}

const result = add(1, 2);
console.log(result);
