import {add, log} from './module';

const result = add(1, 2)
console.log(result)
