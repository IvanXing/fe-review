export function log() {
    return true;
}

export function add(a, b) {
    return a + b;
}