const webpack = require('webpack')

webpack.define(function() {
    
})