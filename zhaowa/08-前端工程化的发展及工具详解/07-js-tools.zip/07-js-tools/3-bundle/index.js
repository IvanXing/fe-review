const module = require('./module');
console.log(module.var1);